import React, { useState } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet, Image } from 'react-native';

export default function App() {
  const [text, setText] = useState('');
  const [posts, setPosts] = useState([]);

  const addItem = () => {
    if (text.trim() !== '') {
      const newPost = {
        id: Date.now().toString(),
        caption: text,
        time: 'just now',
      };
      setPosts([newPost, ...posts]); // new posts appear on top
      setText('');
    }
  };

  return (
    <View style={styles.container}>
      {/* Header with profile pic + username */}
      <View style={styles.headerRow}>
        <Image
          source={require('profile.jpg')} // change to your own pic if you like
          style={styles.profileImage}
        />
        <View>
          <Text style={styles.header}>@genebeex</Text>
          <Text style={styles.subHeader}>Genevieve Gamay</Text>
        </View>
      </View>

      {/* Input Field + Add Button */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Write a caption..."
          placeholderTextColor="#888"
          value={text}
          onChangeText={setText}
          onSubmitEditing={addItem}
          returnKeyType="done"
        />
        <Button title="Post" color="#e1306c" onPress={addItem} />
      </View>

      {/* Posts Feed */}
      <FlatList
        data={posts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.postCard}>
            <Text style={styles.username}>@genebeex</Text>
            <Text style={styles.caption}>{item.caption}</Text>
            <Text style={styles.time}>{item.time}</Text>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000', // dark mode background
    padding: 20,
    paddingTop: 50,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
  },
  profileImage: {
    width: 55,
    height: 55,
    borderRadius: 30,
    borderWidth: 2,
    borderColor: '#e1306c',
    marginRight: 15,
  },
  header: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 20,
  },
  subHeader: {
    color: '#aaa',
    fontSize: 14,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 25,
  },
  input: {
    flex: 1,
    borderColor: '#e1306c',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
    color: '#fff',
    marginRight: 10,
  },
  postCard: {
    backgroundColor: '#111',
    padding: 15,
    borderRadius: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 2,
  },
  username: {
    color: '#e1306c',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  caption: {
    color: '#fff',
    fontSize: 16,
    marginBottom: 5,
  },
  time: {
    color: '#999',
    fontSize: 12,
    textAlign: 'right',
  },
});
